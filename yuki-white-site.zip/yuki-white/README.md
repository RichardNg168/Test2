# Yuki & White — static site

Five pages, hand-built, no framework. Deploy by dragging the unzipped folder onto Netlify Drop.

```
index.html        Home
about.html        About Us
services.html     Services (office / carpet / disinfecting / plants / renovation)
faq.html          FAQ  — includes FAQPage JSON-LD
contact.html      Contact Us — Netlify form + map + LocalBusiness JSON-LD
thank-you.html    Form success page (noindex)
assets/styles.css
assets/main.js
robots.txt · sitemap.xml
build/            Optional. Python generator for the shared header/footer. Delete before deploy.
```

## Before go-live

1. **Self-host the images.** Every `<img>` currently points at `https://yuki.com.sg/wp-content/uploads/...`. Those paths die the moment WordPress is switched off. Download them into `assets/img/` and find-replace the prefix.
2. **Delete `build/`** from the deploy folder — it is a source tool, not a site asset.
3. **Netlify form.** The contact form uses `data-netlify="true"` with a honeypot named `company-website` and posts to `/thank-you.html`. Add the notification email under Site configuration → Forms.
4. **Analytics.** No GA4 or pixel is installed yet.

## Design tokens

| Token | Value | Use |
|---|---|---|
| `--snow` | `#F4F6F4` | page ground |
| `--paper` | `#FFFFFF` | cards, panels |
| `--sumi` | `#14191A` | headings, ink |
| `--sumi-soft` | `#33443E` | body text (deep slate-green, no grey anywhere) |
| `--pine` | `#2F5D4E` | accent, buttons, active states |
| `--line` | `#D6DCD7` | hairlines only, never text |

Type: **Zen Old Mincho** (display) + **Zen Kaku Gothic New** (body), both Google Fonts.

## Notes

- Copy is rewritten from the existing site — same claims and same service scope, edited for grammar and length. Nothing new was invented about the business.
- The FAQ answers on pricing, consumables and minimum contract are drafted from standard practice. Confirm each with the client before publishing.
- Accessibility: skip link, visible focus rings, `aria-current` nav state, `prefers-reduced-motion` honoured throughout.
