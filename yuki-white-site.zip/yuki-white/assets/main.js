/* Yuki & White — site behaviour */
(function () {
  'use strict';

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- Mobile navigation ---- */
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---- Sticky header hairline ---- */
  var head = document.querySelector('.site-head');
  if (head) {
    var onScroll = function () {
      head.classList.toggle('is-stuck', window.scrollY > 12);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---- Scroll reveal ---- */
  var reveals = document.querySelectorAll('.reveal');
  if (reveals.length) {
    if (reduce || !('IntersectionObserver' in window)) {
      Array.prototype.forEach.call(reveals, function (el) { el.classList.add('is-in'); });
    } else {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-in');
            io.unobserve(entry.target);
          }
        });
      }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
      Array.prototype.forEach.call(reveals, function (el) { io.observe(el); });
    }
  }

  /* ---- Cleaning cadence rail ---- */
  var cadence = document.getElementById('cadence');
  if (cadence) {
    var opts = cadence.querySelectorAll('.cad-opt');
    var days = cadence.querySelectorAll('.day');
    var note = cadence.querySelector('.cadence-note');

    var paint = function (btn) {
      var picked = btn.getAttribute('data-days').split(',');
      Array.prototype.forEach.call(days, function (day, i) {
        var on = picked.indexOf(String(i)) !== -1;
        var apply = function () { day.classList.toggle('is-visit', on); };
        if (reduce) { apply(); } else { setTimeout(apply, i * 55); }
      });
      if (note) { note.textContent = btn.getAttribute('data-note'); }
      Array.prototype.forEach.call(opts, function (o) {
        var isOn = o === btn;
        o.classList.toggle('is-on', isOn);
        o.setAttribute('aria-pressed', isOn ? 'true' : 'false');
      });
    };

    Array.prototype.forEach.call(opts, function (btn) {
      btn.addEventListener('click', function () { paint(btn); });
    });

    var initial = cadence.querySelector('.cad-opt.is-on') || opts[0];
    if (initial) { paint(initial); }
  }

  /* ---- Year stamp ---- */
  var years = document.querySelectorAll('[data-year]');
  Array.prototype.forEach.call(years, function (el) {
    el.textContent = new Date().getFullYear();
  });
})();
